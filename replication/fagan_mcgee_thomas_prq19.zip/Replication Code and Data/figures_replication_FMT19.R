# The Power of the Party: Conflict Expansion and the Agenda Diversity of Interest Groups
# By: E.J. Fagan, Zachary A. McGee, and Herschel F. Thomas III
# Code for Figures 1, 2, and 3

# Load packages, set working directory, and import data
library(ggplot2)
library(reshape2)
library(plyr)

#setwd("/Users/zacharymcgee/Dropbox/Conflict Expansion and Parties/Data")
setwd("/Users/zacharymcgee/Dropbox/Conflict Expansion and Parties/Paper/PRQ Submission/RR/Cond Act/Final Submission/Replication Code and Data")

topicdata <- read.csv(file = "data_for_Rplot.csv", header = TRUE, stringsAsFactors = FALSE)

# Diverse Agenda: Communication Workers of America (CWA) | mlid 8941712 (MLID) topicdata[84,]
cwa_raw <- topicdata[84,138:157]

# Narrow Agenda: National Community Pharmacists Association (NCPA) | 24094 (MLID) topicdata[144,]
ncpa_raw <- topicdata[144,138:157]

# Reshape the data
cwa <- melt(cwa_raw, na.rm=F)
ncpa <- melt(ncpa_raw, na.rm=F)

# Apply major topic text from the Policy Agendas Project
pap <- c("Macroeconomics", "Civil Rights & Liberties", "Health", "Agriculture", "Labor", "Education", "Environment", "Energy", "Immigration", "Transportation", "Law, Crime, & Family", "Social Welfare", "Housing", "Banking & Finance", "Defense", "Science & Technology", "Foreign Trade", "International Affairs", "Government Operations", "Public Lands")
cwa$variable <- pap
ncpa$variable <- pap

# Figure 1
ggplot(data = cwa, aes(x=reorder(variable, -value), y=value)) + geom_col(fill="steelblue", position = position_stack(reverse = TRUE)) + coord_flip() + scale_y_continuous(limits = c(0,40)) + labs(x="Policy Topics", y="Positions by Communication Workers of America") + theme_light()

# Figure 2
ggplot(data = ncpa, aes(x=reorder(variable, -value), y=value)) + geom_col(fill="darkred", position = position_stack(reverse = TRUE)) + coord_flip() + scale_y_continuous(limits = c(0,40)) + labs(x="Policy Topics", y="Positions by National Community Pharmacists Assn.") + theme_light()

# Figure 3
ggplot(data=topicdata, aes(x=co_ideology, y=shannonsh)) + geom_point(size=2, shape=21, color="black", stroke = 1.1) + geom_smooth(method="loess", span=1.4, color="grey50") + theme_minimal()+ labs(x="Party Alignment", y="Agenda Diversity")
